INSERT INTO Employee(name) VALUES ('Manish')
INSERT INTO Employee(name) VALUES ('Thakur')
