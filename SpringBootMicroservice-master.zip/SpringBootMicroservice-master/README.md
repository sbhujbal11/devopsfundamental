# SpringBootMicroservice
The application demonstrates REST services using spring boot. The application can be deployed to a servlet container or can run as 
standalone application on port 9000.